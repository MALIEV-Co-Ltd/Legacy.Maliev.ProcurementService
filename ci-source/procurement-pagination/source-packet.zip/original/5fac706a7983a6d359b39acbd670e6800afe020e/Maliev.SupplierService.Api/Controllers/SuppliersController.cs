﻿// <copyright file="SuppliersController.cs" company="Maliev Company Limited">
// Copyright (c) Maliev Company Limited. All rights reserved.
// </copyright>

namespace Maliev.SupplierService.Api.Controllers
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using Maliev.Entities.ViewModels;
    using Maliev.SupplierService.Common.Enumerations;
    using Maliev.SupplierService.Data.Database.SupplierContext;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Controller.
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    [Route("[controller]")]
    [ApiController]
    [ApiConventionType(typeof(DefaultApiConventions))]
    [Authorize(AuthenticationSchemes=JwtBearerDefaults.AuthenticationScheme)]
    public class SuppliersController : ControllerBase
    {
        /// <summary>
        /// The context.
        /// </summary>
        private readonly SupplierContext supplierContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="SuppliersController" /> class.
        /// </summary>
        /// <param name="supplierContext">The context.</param>
        public SuppliersController(SupplierContext supplierContext)
        {
            this.supplierContext = supplierContext;
        }

        /// <summary>
        /// Create supplier.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns>
        ///   <see cref="ActionResult" />.
        /// </returns>
        [HttpPost]
        public async Task<ActionResult> CreateSupplierAsync(Supplier item)
        {
            if (item == null)
            {
                return this.BadRequest();
            }

            Supplier supplier = new Supplier
            {
                Name = item.Name,
                Website = item.Website,
                TaxNumber = item.TaxNumber,
                Email = item.Email,
                Note = item.Note,
                Telephone = item.Telephone,
                Mobile = item.Mobile,
                Fax = item.Fax,
                CreatedDate = DateTime.UtcNow,
                ModifiedDate = DateTime.UtcNow,
            };

            await this.supplierContext.Supplier.AddAsync(supplier);
            await this.supplierContext.SaveChangesAsync();
            return this.CreatedAtRoute("GetSupplier", new { supplierId = supplier.Id }, supplier);
        }

        /// <summary>
        /// Delete supplier.
        /// </summary>
        /// <param name="supplierId">The identifier.</param>
        /// <returns>
        ///   <see cref="Task{ActionResult}" />.
        /// </returns>
        [HttpDelete("{supplierId:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesDefaultResponseType]
        public async Task<ActionResult> DeleteSupplierAsync(int supplierId)
        {
            var supplier = await this.supplierContext.Supplier.FindAsync(supplierId);
            if (supplier == null)
            {
                return this.NotFound();
            }

            this.supplierContext.Supplier.Remove(supplier);
            await this.supplierContext.SaveChangesAsync();
            return this.NoContent();
        }

        /// <summary>
        /// Get paginated suppliers.
        /// </summary>
        /// <param name="sort">The sort.</param>
        /// <param name="search">The search.</param>
        /// <param name="index">The index.</param>
        /// <param name="size">The size.</param>
        /// <returns>
        ///   <see cref="PaginatedListWebApi{Supplier}" />.
        /// </returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesDefaultResponseType]
        public async Task<ActionResult<PaginatedListWebApi<Supplier>>> GetPaginatedSuppliersAsync(SupplierSortType? sort, string search, int? index, int? size)
        {
            IQueryable<Supplier> query = from s in this.supplierContext.Supplier.AsNoTracking()
                                         select s;
            switch (sort)
            {
                case SupplierSortType.SupplierId_Ascending:
                    query = query.OrderBy(o => o.Id);
                    break;

                case SupplierSortType.SupplierId_Descending:
                    query = query.OrderByDescending(o => o.Id);
                    break;

                case SupplierSortType.SupplierName_Ascending:
                    query = query.OrderBy(o => o.Name);
                    break;

                case SupplierSortType.SupplierName_Descending:
                    query = query.OrderByDescending(o => o.Name);
                    break;

                case SupplierSortType.SupplierCreatedDate_Ascending:
                    query = query.OrderBy(o => o.CreatedDate);
                    break;

                case SupplierSortType.SupplierCreatedDate_Descending:
                    query = query.OrderByDescending(o => o.CreatedDate);
                    break;

                case SupplierSortType.SupplierModifiedDate_Ascending:
                    query = query.OrderBy(o => o.ModifiedDate);
                    break;

                case SupplierSortType.SupplierModifiedDate_Descending:
                    query = query.OrderByDescending(o => o.ModifiedDate);
                    break;

                default:
                    query = query.OrderBy(o => o.Id);
                    break;
            }

            if (!string.IsNullOrEmpty(search))
            {
                bool isNumeric = int.TryParse(search, out int searchAsInteger);
                query = query.Where(s => isNumeric ? s.Id == searchAsInteger : (s.Name != null && s.Name.ToLower().Contains(search))
                || (s.Website != null && s.Website.ToLower().Contains(search))
                || (s.TaxNumber != null && s.TaxNumber.ToLower().Contains(search))
                || (s.Email != null && s.Email.ToLower().Contains(search)));
            }

            PaginatedListWebApi<Supplier> suppliers = await PaginatedListWebApi<Supplier>.CreateAsync(query, index ?? 1, size ?? await query.CountAsync());
            if (suppliers == null || suppliers.Items.Count == 0)
            {
                return this.NotFound();
            }

            return suppliers;
        }

        /// <summary>
        /// Get supplier by Id.
        /// </summary>
        /// <param name="supplierId">The identifier.</param>
        /// <returns>
        ///   <see cref="Supplier" />.
        /// </returns>
        [HttpGet("{supplierId:int}", Name = "GetSupplier")]
        public async Task<ActionResult<Supplier>> GetSupplierAsync(int supplierId)
        {
            var supplier = await this.supplierContext.Supplier.FindAsync(supplierId);
            if (supplier == null)
            {
                return this.NotFound();
            }

            return supplier;
        }

        /// <summary>
        /// Update supplier.
        /// </summary>
        /// <param name="supplierId">The identifier.</param>
        /// <param name="item">The item.</param>
        /// <returns>
        ///   <see cref="Task{ActionResult}" />.
        /// </returns>
        [HttpPut("{supplierId:int}")]
        public async Task<ActionResult> UpdateSupplierAsync(int supplierId, Supplier item)
        {
            if (item == null)
            {
                return this.BadRequest();
            }

            var supplier = await this.supplierContext.Supplier.FindAsync(supplierId);
            if (supplier == null)
            {
                return this.NotFound();
            }

            supplier.Email = item.Email;
            supplier.ModifiedDate = DateTime.UtcNow;
            supplier.Name = item.Name;
            supplier.TaxNumber = item.TaxNumber;
            supplier.Website = item.Website;
            supplier.Fax = item.Fax;
            supplier.Mobile = item.Mobile;
            supplier.Telephone = item.Telephone;
            supplier.Note = item.Note;

            this.supplierContext.Update(supplier);
            await this.supplierContext.SaveChangesAsync();

            return this.NoContent();
        }

        /// <summary>
        /// Determines whether [is valid address] [the specified address].
        /// </summary>
        /// <param name="address">The address.</param>
        /// <returns>
        ///   <c>true</c> if [is valid address] [the specified address]; otherwise, <c>false</c>.
        /// </returns>
        private bool IsValidAddress(Address address)
        {
            if (address == null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(address.Address1))
            {
                return false;
            }

            if (address.CountryId == 0)
            {
                return false;
            }

            return true;
        }
    }
}