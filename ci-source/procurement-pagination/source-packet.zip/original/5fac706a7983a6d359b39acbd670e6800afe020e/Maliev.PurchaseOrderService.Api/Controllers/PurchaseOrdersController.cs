﻿// <copyright file="PurchaseOrdersController.cs" company="Maliev Company Limited">
// Copyright (c) Maliev Company Limited. All rights reserved.
// </copyright>

namespace Maliev.PurchaseOrderService.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Maliev.Entities.ViewModels;
    using Maliev.PurchaseOrderService.Common.Enumerations;
    using Maliev.PurchaseOrderService.Data.Database.PurchaseOrderContext;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Controller.
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    [Route("[controller]")]
    [ApiController]
    [ApiConventionType(typeof(DefaultApiConventions))]
    [Authorize(AuthenticationSchemes=JwtBearerDefaults.AuthenticationScheme)]
    public class PurchaseOrdersController : ControllerBase
    {
        /// <summary>
        /// The context.
        /// </summary>
        private readonly PurchaseOrderContext context;

        /// <summary>
        /// Initializes a new instance of the <see cref="PurchaseOrdersController" /> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public PurchaseOrdersController(PurchaseOrderContext context)
        {
            this.context = context;
        }

        /// <summary>
        /// Create purchase order.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns>
        ///   <see cref="Task{IActionResult}" />.
        /// </returns>
        [HttpPost]
        public async Task<IActionResult> CreatePurchaseOrderAsync(PurchaseOrder item)
        {
            if (item == null)
            {
                return this.BadRequest("PurchaseOrder data is required");
            }

            PurchaseOrder purchaseOrder = new PurchaseOrder
            {
                BillingAddressId = item.BillingAddressId,
                CreatedDate = DateTime.UtcNow,
                EmployeeId = item.EmployeeId,
                Fob = item.Fob,
                ModifiedDate = DateTime.UtcNow,
                ShippingAddressId = item.ShippingAddressId,
                ShippingMethod = item.ShippingMethod,
                SupplierId = item.SupplierId,
                Terms = item.Terms,
                Notes = item.Notes,
                BillingContactPerson = item.BillingContactPerson,
                BillingFax = item.BillingFax,
                BillingMobile = item.BillingMobile,
                BillingTelephone = item.BillingTelephone,
                ShippingContactPerson = item.ShippingContactPerson,
                ShippingFax = item.ShippingFax,
                ShippingMobile = item.ShippingMobile,
                ShippingTelephone = item.ShippingTelephone,
                SupplierContactPerson = item.ShippingContactPerson,
            };

            await this.context.PurchaseOrder.AddAsync(purchaseOrder);
            await this.context.SaveChangesAsync();

            return this.CreatedAtRoute("GetPurchaseOrder", new { purchaseOrderId = purchaseOrder.Id }, purchaseOrder);
        }

        /// <summary>
        /// Delete purchase order.
        /// </summary>
        /// <param name="purchaseOrderId">The purchase order identifier.</param>
        /// <returns>
        ///   <see cref="Task{IActionResult}" />.
        /// </returns>
        [HttpDelete("{purchaseOrderId:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesDefaultResponseType]
        public async Task<IActionResult> DeletePurchaseOrderAsync(int purchaseOrderId)
        {
            var item = await this.context.PurchaseOrder.FindAsync(purchaseOrderId);
            if (item == null)
            {
                return this.NotFound();
            }

            this.context.PurchaseOrder.Remove(item);
            await this.context.SaveChangesAsync();

            return this.NoContent();
        }

        /// <summary>
        /// Get paginated purchase orders.
        /// </summary>
        /// <param name="sort">The sort.</param>
        /// <param name="search">The search.</param>
        /// <param name="index">The index.</param>
        /// <param name="size">The size.</param>
        /// <returns>
        ///   <see cref="List{PurchaseOrder}" />.
        /// </returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesDefaultResponseType]
        public async Task<ActionResult<PaginatedListWebApi<PurchaseOrder>>> GetPaginatedAsync(PurchaseOrderSortType? sort, string search, int? index, int? size)
        {
            // make search query lowercase by default
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
            }

            IQueryable<PurchaseOrder> query = from s in this.context.PurchaseOrder
                                         .AsNoTracking()
                                              select s;
            switch (sort)
            {
                case PurchaseOrderSortType.PurchaseOrderId_Ascending:
                    query = query.OrderBy(o => o.Id);
                    break;

                case PurchaseOrderSortType.PurchaseOrderId_Descending:
                    query = query.OrderByDescending(o => o.Id);
                    break;

                case PurchaseOrderSortType.PurchaseOrderCreatedDate_Ascending:
                    query = query.OrderBy(o => o.CreatedDate);
                    break;

                case PurchaseOrderSortType.PurchaseOrderCreatedDate_Descending:
                    query = query.OrderByDescending(o => o.CreatedDate);
                    break;

                default:
                    query = query.OrderBy(o => o.Id);
                    break;
            }

            if (!string.IsNullOrEmpty(search))
            {
                bool isNumeric = int.TryParse(search, out int searchAsInteger);
                query = query.Where(s => s.Id.ToString().ToLower().Contains(search) ||
                (!string.IsNullOrEmpty(s.Notes) && s.Notes.ToString().ToLower().Contains(search)));
            }

            PaginatedListWebApi<PurchaseOrder> purchaseOrders = await PaginatedListWebApi<PurchaseOrder>.CreateAsync(query, index ?? 1, size ?? await query.CountAsync());
            if (purchaseOrders == null || purchaseOrders.Items.Count == 0)
            {
                return this.NotFound();
            }

            return purchaseOrders;
        }

        /// <summary>
        /// Get purchase order by Id.
        /// </summary>
        /// <param name="purchaseOrderId">The identifier.</param>
        /// <returns>
        ///   <see cref="ActionResult{PurchaseOrder}" />.
        /// </returns>
        [HttpGet("{purchaseOrderId:int}", Name = "GetPurchaseOrder")]
        public async Task<ActionResult<PurchaseOrder>> GetPurchaseOrderAsync(int purchaseOrderId)
        {
            var purchaseOrder = await this.context.PurchaseOrder.FindAsync(purchaseOrderId);

            if (purchaseOrder == null)
            {
                return this.NotFound();
            }

            return purchaseOrder;
        }

        /// <summary>
        /// Update purchase order.
        /// </summary>
        /// <param name="purchaseOrderId">The identifier.</param>
        /// <param name="item">The item.</param>
        /// <returns>
        ///   <see cref="Task{ActionResult}" />.
        /// </returns>
        [HttpPut("{purchaseOrderId:int}")]
        public async Task<ActionResult> UpdatePurchaseOrderAsync(int purchaseOrderId, PurchaseOrder item)
        {
            if (item == null)
            {
                return this.BadRequest();
            }

            var purchaseOrder = await this.context.PurchaseOrder.FindAsync(purchaseOrderId);
            if (purchaseOrder == null)
            {
                return this.NotFound();
            }

            purchaseOrder.BillingAddressId = item.BillingAddressId;
            purchaseOrder.EmployeeId = item.EmployeeId;
            purchaseOrder.Fob = item.Fob;
            purchaseOrder.ModifiedDate = DateTime.UtcNow;
            purchaseOrder.ShippingAddressId = item.ShippingAddressId;
            purchaseOrder.ShippingMethod = item.ShippingMethod;
            purchaseOrder.SupplierId = item.SupplierId;
            purchaseOrder.Terms = item.Terms;
            purchaseOrder.Notes = item.Notes;
            purchaseOrder.BillingContactPerson = item.BillingContactPerson;
            purchaseOrder.BillingFax = item.BillingFax;
            purchaseOrder.BillingMobile = item.BillingMobile;
            purchaseOrder.BillingTelephone = item.BillingTelephone;
            purchaseOrder.ShippingContactPerson = item.ShippingContactPerson;
            purchaseOrder.ShippingFax = item.ShippingFax;
            purchaseOrder.ShippingMobile = item.ShippingMobile;
            purchaseOrder.ShippingTelephone = item.ShippingTelephone;
            purchaseOrder.SupplierContactPerson = item.SupplierContactPerson;

            this.context.PurchaseOrder.Update(purchaseOrder);
            await this.context.SaveChangesAsync();

            return this.NoContent();
        }
    }
}