// <copyright file="Index.cshtml.cs" company="Maliev Company Limited">
// Copyright (c) Maliev Company Limited. All rights reserved.
// </copyright>

namespace Maliev.Intranet.Pages.PurchaseOrders
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Maliev.EmployeeService.Data.Database.EmployeeContext;
    using Maliev.Entities.ViewModels;
    using Maliev.Identities;
    using Maliev.PurchaseOrderService.Common.Enumerations;
    using Maliev.PurchaseOrderService.Data.Database.PurchaseOrderContext;
    using Maliev.Service.WebApi;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.RazorPages;
    using Microsoft.AspNetCore.WebUtilities;

    /// <summary>
    /// Index.
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.RazorPages.PageModel" />
    public class Index : PageModel
    {
        /// <summary>
        /// The user manager.
        /// </summary>
        private readonly UserManager<ApplicationEmployee> userManager;

        /// <summary>
        /// The web API service.
        /// </summary>
        private readonly IWebApiService webApiService;

        /// <summary>
        /// Initializes a new instance of the <see cref="Index" /> class.
        /// </summary>
        /// <param name="userManager">The user manager.</param>
        /// <param name="webApiService">The web API service.</param>
        /// <param name="clientFactory">The client factory.</param>
        public Index(UserManager<ApplicationEmployee> userManager, IWebApiService webApiService, IHttpClientFactory clientFactory)
        {
            this.userManager = userManager;
            this.webApiService = webApiService;

            if (this.webApiService != null)
            {
                this.webApiService.SetClientFactory(clientFactory);
            }
        }

        /// <summary>
        /// Gets or sets the access token.
        /// </summary>
        /// <value>
        /// The access token.
        /// </value>
        public string AccessToken
        {
            get => this.HttpContext.Session.GetString("access_token");
            set => this.HttpContext.Session.SetString("access_token", value);
        }

        /// <summary>
        /// Gets or sets the current sort.
        /// </summary>
        /// <value>
        /// The current sort.
        /// </value>
        public PurchaseOrderSortType? CurrentSort { get; set; }

        /// <summary>
        /// Gets or sets the employees.
        /// </summary>
        /// <value>
        /// The employees.
        /// </value>
        public List<Employee> Employees { get; set; } = new List<Employee>();

        /// <summary>
        /// Gets or sets the size of the page.
        /// </summary>
        /// <value>
        /// The size of the page.
        /// </value>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or sets the purchase order created date sort.
        /// </summary>
        /// <value>
        /// The purchase order created date sort.
        /// </value>
        public PurchaseOrderSortType PurchaseOrderCreatedDateSort { get; set; }

        /// <summary>
        /// Gets or sets the purchase order identifier sort.
        /// </summary>
        /// <value>
        /// The purchase order identifier sort.
        /// </value>
        public PurchaseOrderSortType PurchaseOrderIdSort { get; set; }

        /// <summary>
        /// Gets or sets the purchase orders.
        /// </summary>
        /// <value>
        /// The purchase orders.
        /// </value>
        public PaginatedListWebApi<PurchaseOrder> PurchaseOrders { get; set; } = new PaginatedListWebApi<PurchaseOrder>();

        /// <summary>
        /// Gets or sets the purchase order search.
        /// </summary>
        /// <value>
        /// The purchase order search.
        /// </value>
        public string PurchaseOrderSearch { get; set; }

        /// <summary>
        /// Gets or sets the index of the target page.
        /// </summary>
        /// <value>
        /// The index of the target page.
        /// </value>
        public int TargetPageIndex { get; set; }

        /// <summary>
        /// Called when [get asynchronous].
        /// </summary>
        /// <param name="sort">The sort.</param>
        /// <param name="search">The search.</param>
        /// <param name="index">The index.</param>
        /// <param name="size">The size.</param>
        /// <returns>
        ///   <see cref="Task{IActionResult}" />.
        /// </returns>
        public async Task<IActionResult> OnGetAsync(string sort, string search, int? index, int size)
        {
            ApplicationEmployee user = await this.userManager.GetUserAsync(this.User).ConfigureAwait(false);
            if (user == null)
            {
                return this.NotFound("Employee not found");
            }

            // Determine page size
            this.PageSize = size > 0 ? size : 25;

            // Get current sort setting
            if (Enum.TryParse(sort, out PurchaseOrderSortType result))
            {
                this.CurrentSort = result;
            }

            // Determine search
            this.PurchaseOrderSearch = search;
            if (!string.IsNullOrEmpty(this.PurchaseOrderSearch))
            {
                this.TargetPageIndex = 1;
            }
            else
            {
                this.TargetPageIndex = index.HasValue ? (int)index : 1;
            }

            // Store sorting
            this.PurchaseOrderIdSort = this.CurrentSort == PurchaseOrderSortType.PurchaseOrderId_Ascending ? PurchaseOrderSortType.PurchaseOrderId_Descending : PurchaseOrderSortType.PurchaseOrderId_Ascending;
            this.PurchaseOrderCreatedDateSort = this.CurrentSort == PurchaseOrderSortType.PurchaseOrderCreatedDate_Ascending ? PurchaseOrderSortType.PurchaseOrderCreatedDate_Descending : PurchaseOrderSortType.PurchaseOrderCreatedDate_Ascending;

            this.AccessToken = await this.webApiService.RequestJwtTokenAsync(user.UserName, user.Id, this.AccessToken).ConfigureAwait(false);

            await Task.WhenAll(new[]
            {
                this.GetPaginatedPurchaseOrdersAsync(),
                this.GetEmployeesAsnyc(),
            }).ConfigureAwait(false);

            return this.Page();
        }

        /// <summary>
        /// Called when [get change item count asynchronous].
        /// </summary>
        /// <param name="size">The size.</param>
        /// <returns>
        ///   <see cref="IActionResult" />.
        /// </returns>
        public async Task<IActionResult> OnGetChangeItemCountAsync(string size)
        {
            this.PageSize = Convert.ToInt32(size);

            ApplicationEmployee user = await this.userManager.GetUserAsync(this.User).ConfigureAwait(false);
            if (user == null)
            {
                return this.BadRequest("Employee not exist");
            }

            this.AccessToken = await this.webApiService.RequestJwtTokenAsync(user.UserName, user.Id, this.AccessToken).ConfigureAwait(false);

            await Task.WhenAll(new[]
            {
                this.GetPaginatedPurchaseOrdersAsync(),
                this.GetEmployeesAsnyc(),
            }).ConfigureAwait(false);

            return this.Page();
        }

        /// <summary>
        /// Gets the employees asnyc.
        /// </summary>
        /// <returns>
        ///   <see cref="Task" />.
        /// </returns>
        private async Task GetEmployeesAsnyc()
        {
            var apiResponse = await this.webApiService.GetAs<PaginatedListWebApi<Employee>>($"/employees/", this.AccessToken).ConfigureAwait(false);
            if (!apiResponse.Response.IsSuccessStatusCode)
            {
                this.ModelState.AddModelError(string.Empty, $"Error getting employees - {apiResponse.Response.StatusCode}");
                return;
            }

            this.Employees = apiResponse.Item.Items;
        }

        /// <summary>
        /// Gets the paginated purchase orders asynchronous.
        /// </summary>
        /// <returns>
        ///   <see cref="Task" />.
        /// </returns>
        private async Task GetPaginatedPurchaseOrdersAsync()
        {
            if (this.TargetPageIndex == 0)
            {
                this.TargetPageIndex = 1;
            }

            if (!this.CurrentSort.HasValue)
            {
                this.CurrentSort = PurchaseOrderSortType.PurchaseOrderCreatedDate_Descending;
            }

            var queryString = new Dictionary<string, string>()
            {
                { "sort", this.CurrentSort.ToString() },
                { "search", string.IsNullOrEmpty(this.PurchaseOrderSearch) ? string.Empty : this.PurchaseOrderSearch },
                { "index", this.TargetPageIndex.ToString() },
                { "size", this.PageSize.ToString() },
            };

            var requestUri = QueryHelpers.AddQueryString($"/purchaseorders/", queryString);
            var apiResponse = await this.webApiService.GetAs<PaginatedListWebApi<PurchaseOrder>>(requestUri, this.AccessToken).ConfigureAwait(false);
            if (!apiResponse.Response.IsSuccessStatusCode)
            {
                this.ModelState.AddModelError(string.Empty, $"Could not get purchase orders - {apiResponse.Response.StatusCode}");
                return;
            }

            this.PurchaseOrders = apiResponse.Item;
        }
    }
}