// <copyright file="Index.cshtml.cs" company="Maliev Company Limited">
// Copyright (c) Maliev Company Limited. All rights reserved.
// </copyright>

namespace Maliev.Intranet.Pages.Suppliers
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Maliev.Entities.ViewModels;
    using Maliev.Identities;
    using Maliev.Service.WebApi;
    using Maliev.SupplierService.Common.Enumerations;
    using Maliev.SupplierService.Data.Database.SupplierContext;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.RazorPages;
    using Microsoft.AspNetCore.WebUtilities;

    /// <summary>
    /// Index.
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.RazorPages.PageModel" />
    public class Index : PageModel
    {
        /// <summary>
        /// The user manager.
        /// </summary>
        private readonly UserManager<ApplicationEmployee> userManager;

        /// <summary>
        /// The web API service.
        /// </summary>
        private readonly IWebApiService webApiService;

        /// <summary>
        /// Initializes a new instance of the <see cref="Index" /> class.
        /// </summary>
        /// <param name="userManager">The user manager.</param>
        /// <param name="clientFactory">The client factory.</param>
        /// <param name="webApiService">The web API service.</param>
        public Index(UserManager<ApplicationEmployee> userManager, IHttpClientFactory clientFactory, IWebApiService webApiService)
        {
            this.userManager = userManager;
            this.webApiService = webApiService;

            webApiService.SetClientFactory(clientFactory);
        }

        /// <summary>
        /// Gets or sets the access token.
        /// </summary>
        /// <value>
        /// The access token.
        /// </value>
        public string AccessToken
        {
            get => this.HttpContext.Session.GetString("access_token");
            set => this.HttpContext.Session.SetString("access_token", value);
        }

        /// <summary>
        /// Gets or sets the current sort.
        /// </summary>
        /// <value>
        /// The current sort.
        /// </value>
        public SupplierSortType CurrentSort { get; set; }

        /// <summary>
        /// Gets or sets the size of the page.
        /// </summary>
        /// <value>
        /// The size of the page.
        /// </value>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or sets the supplier created date sort.
        /// </summary>
        /// <value>
        /// The supplier created date sort.
        /// </value>
        public SupplierSortType SupplierCreatedDateSort { get; set; }

        /// <summary>
        /// Gets or sets the supplier identifier sort.
        /// </summary>
        /// <value>
        /// The supplier identifier sort.
        /// </value>
        public SupplierSortType SupplierIdSort { get; set; }

        /// <summary>
        /// Gets or sets the supplier modified date sort.
        /// </summary>
        /// <value>
        /// The supplier modified date sort.
        /// </value>
        public SupplierSortType SupplierModifiedDateSort { get; set; }

        /// <summary>
        /// Gets or sets the supplier name sort.
        /// </summary>
        /// <value>
        /// The supplier name sort.
        /// </value>
        public SupplierSortType SupplierNameSort { get; set; }

        /// <summary>
        /// Gets or sets the suppliers.
        /// </summary>
        /// <value>
        /// The suppliers.
        /// </value>
        public PaginatedListWebApi<Supplier> Suppliers { get; set; } = new PaginatedListWebApi<Supplier>();

        /// <summary>
        /// Gets or sets the supplier search.
        /// </summary>
        /// <value>
        /// The supplier search.
        /// </value>
        public string SupplierSearch { get; set; }

        /// <summary>
        /// Gets or sets the index of the target page.
        /// </summary>
        /// <value>
        /// The index of the target page.
        /// </value>
        public int TargetPageIndex { get; set; }

        /// <summary>
        /// Called when [get asynchronous].
        /// </summary>
        /// <param name="sort">The sort.</param>
        /// <param name="search">The search.</param>
        /// <param name="index">The index.</param>
        /// <param name="size">The size.</param>
        /// <returns>
        ///   <see cref="Task{IActionResult}" />.
        /// </returns>
        public async Task<IActionResult> OnGetAsync(string sort, string search, int? index, int size)
        {
            // Determine page size
            this.PageSize = size > 0 ? size : 25;

            // Get current sort setting
            if (Enum.TryParse(sort, out SupplierSortType result))
            {
                this.CurrentSort = result;
            }

            // Determine search
            this.SupplierSearch = search;
            if (!string.IsNullOrEmpty(this.SupplierSearch))
            {
                this.TargetPageIndex = 1;
            }
            else
            {
                this.TargetPageIndex = index.HasValue ? (int)index : 1;
            }

            // Store sorting
            this.SupplierIdSort = this.CurrentSort == SupplierSortType.SupplierId_Ascending ? SupplierSortType.SupplierId_Descending : SupplierSortType.SupplierId_Ascending;
            this.SupplierNameSort = this.CurrentSort == SupplierSortType.SupplierName_Ascending ? SupplierSortType.SupplierName_Descending : SupplierSortType.SupplierName_Ascending;
            this.SupplierCreatedDateSort = this.CurrentSort == SupplierSortType.SupplierCreatedDate_Ascending ? SupplierSortType.SupplierCreatedDate_Descending : SupplierSortType.SupplierCreatedDate_Ascending;
            this.SupplierModifiedDateSort = this.CurrentSort == SupplierSortType.SupplierModifiedDate_Ascending ? SupplierSortType.SupplierModifiedDate_Descending : SupplierSortType.SupplierModifiedDate_Ascending;

            return await this.GetPaginatedSuppliersAsync().ConfigureAwait(false);
        }

        /// <summary>
        /// Called when [get change item count asynchronous].
        /// </summary>
        /// <param name="size">The size.</param>
        /// <returns>
        ///   <see cref="IActionResult" />.
        /// </returns>
        public async Task<IActionResult> OnGetChangeItemCountAsync(string size)
        {
            this.PageSize = Convert.ToInt32(size);
            return await this.GetPaginatedSuppliersAsync().ConfigureAwait(false);
        }

        /// <summary>
        /// Gets the paginated suppliers asynchronous.
        /// </summary>
        /// <returns>
        ///   <see cref="Task" />.
        /// </returns>
        private async Task<IActionResult> GetPaginatedSuppliersAsync()
        {
            if (this.TargetPageIndex == 0)
            {
                this.TargetPageIndex = 1;
            }

            ApplicationEmployee user = await this.userManager.GetUserAsync(this.User).ConfigureAwait(false);
            if (user == null)
            {
                return this.BadRequest("Employee not exist");
            }

            this.AccessToken = await this.webApiService.RequestJwtTokenAsync(user.UserName, user.Id, this.AccessToken).ConfigureAwait(false);
            var queryString = new Dictionary<string, string>()
            {
                { "sort", this.CurrentSort.ToString() },
                { "search", string.IsNullOrEmpty(this.SupplierSearch) ? string.Empty : this.SupplierSearch },
                { "index", this.TargetPageIndex.ToString() },
                { "size", this.PageSize.ToString() },
            };

            var requestUri = QueryHelpers.AddQueryString($"/suppliers/", queryString);
            var apiResponse = await this.webApiService.GetAs<PaginatedListWebApi<Supplier>>(requestUri, this.AccessToken).ConfigureAwait(false);
            if (apiResponse.Response.IsSuccessStatusCode)
            {
                this.Suppliers = apiResponse.Item;
            }
            else
            {
                this.ModelState.AddModelError(string.Empty, $"Could not get suppliers from API endpoint - {apiResponse.Response.StatusCode}");
            }

            return this.Page();
        }
    }
}