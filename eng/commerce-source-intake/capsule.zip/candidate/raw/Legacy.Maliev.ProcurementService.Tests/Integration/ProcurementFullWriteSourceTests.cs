using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Legacy.Maliev.ProcurementService.Api.Authorization;
using Legacy.Maliev.ProcurementService.Application.Models;
using Legacy.Maliev.ProcurementService.Data;
using Legacy.Maliev.ProcurementService.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Legacy.Maliev.ProcurementService.Tests.Integration;

public sealed class ProcurementFullWriteSourceTests(ProcurementRuntimeFixture fixture)
    : IClassFixture<ProcurementRuntimeFixture>, IAsyncLifetime
{
    private static readonly string[] SupplierStrings = ["Name", "Website", "TaxNumber", "Email", "Note", "Telephone", "Mobile", "Fax"];
    private static readonly string[] OrderStrings = ["SupplierContactPerson", "ShippingContactPerson", "ShippingTelephone", "ShippingMobile", "ShippingFax", "BillingContactPerson", "BillingTelephone", "BillingMobile", "BillingFax", "Fob", "Terms", "ShippingMethod", "Notes"];

    public Task InitializeAsync() => fixture.ResetAsync();
    public Task DisposeAsync() => Task.CompletedTask;

    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 1)]
    [InlineData(false, 2)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 1)]
    [InlineData(true, 2)]
    [InlineData(true, 3)]
    public async Task FullScalarCreateAndUpdatePreserveSourceLiteralsAndIndependentDatabaseReadback(bool purchaseOrder, int mode)
    {
        await using var factory = fixture.CreateFactory(true);
        using var client = purchaseOrder
            ? fixture.ClientAs(factory, "service:procurement-parity", ProcurementPermissions.PurchaseOrdersCreate, ProcurementPermissions.PurchaseOrdersRead, ProcurementPermissions.PurchaseOrdersUpdate)
            : fixture.ClientAs(factory, "employee:procurement-parity", ProcurementPermissions.SuppliersCreate, ProcurementPermissions.SuppliersRead, ProcurementPermissions.SuppliersUpdate);
        await using (var seed = factory.Services.CreateAsyncScope())
        {
            var orders = seed.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
            orders.Addresses.AddRange(new PurchaseOrderAddress { Id = 101, AddressLine1 = "First source address" }, new PurchaseOrderAddress { Id = 102, AddressLine1 = "Second source address" });
            await orders.SaveChangesAsync();
        }
        var route = purchaseOrder ? "/purchaseorders" : "/suppliers";
        var sentinelValues = Values(purchaseOrder, 0, "sentinel");
        using var sentinelCreated = await client.PostAsJsonAsync(route, sentinelValues);
        Assert.Equal(HttpStatusCode.Created, sentinelCreated.StatusCode);
        using var sentinel = await JsonAsync(sentinelCreated);
        int sentinelId = sentinel.RootElement.GetProperty("Id").GetInt32();
        using var sentinelBeforeResponse = await client.GetAsync($"{route}/{sentinelId}");
        using var sentinelBefore = await JsonAsync(sentinelBeforeResponse);
        var createdValues = Values(purchaseOrder, mode, "created");
        using var created = await client.PostAsJsonAsync(route, createdValues);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        Assert.NotNull(created.Headers.Location);
        using var body = await JsonAsync(created);
        AssertFields(body.RootElement, createdValues);
        int id = body.RootElement.GetProperty("Id").GetInt32();
        var createdDate = body.RootElement.GetProperty("CreatedDate").GetDateTime();
        var modifiedDate = body.RootElement.GetProperty("ModifiedDate").GetDateTime();
        Assert.Equal(createdDate, modifiedDate);
        using var located = await client.GetAsync(created.Headers.Location);
        Assert.Equal(HttpStatusCode.OK, located.StatusCode);
        using var locationBody = await JsonAsync(located);
        Assert.Equal(body.RootElement.GetRawText(), locationBody.RootElement.GetRawText());
        await AssertStoredAsync(factory.Services, purchaseOrder, id, createdValues, createdDate, modifiedDate);
        if (mode == 1)
        {
            fixture.Clock.Advance(TimeSpan.FromSeconds(1));
            var populated = Values(purchaseOrder, 0, "intermediate");
            using var filled = await client.PutAsJsonAsync($"{route}/{id}", populated);
            Assert.Equal(HttpStatusCode.NoContent, filled.StatusCode);
            using var filledResponse = await client.GetAsync($"{route}/{id}");
            using var filledBody = await JsonAsync(filledResponse);
            AssertFields(filledBody.RootElement, populated);
            Assert.Equal(createdDate, filledBody.RootElement.GetProperty("CreatedDate").GetDateTime());
            modifiedDate = filledBody.RootElement.GetProperty("ModifiedDate").GetDateTime();
            await AssertStoredAsync(factory.Services, purchaseOrder, id, populated, createdDate, modifiedDate);
        }
        fixture.Clock.Advance(TimeSpan.FromSeconds(1));
        var updatedValues = Values(purchaseOrder, mode, "updated");
        using var updated = await client.PutAsJsonAsync($"{route}/{id}", updatedValues);
        Assert.Equal(HttpStatusCode.NoContent, updated.StatusCode);
        using var freshResponse = await client.GetAsync($"{route}/{id}");
        Assert.Equal(HttpStatusCode.OK, freshResponse.StatusCode);
        using var fresh = await JsonAsync(freshResponse);
        AssertFields(fresh.RootElement, updatedValues);
        Assert.Equal(createdDate, fresh.RootElement.GetProperty("CreatedDate").GetDateTime());
        var changedDate = fresh.RootElement.GetProperty("ModifiedDate").GetDateTime();
        Assert.True(changedDate > modifiedDate);
        await AssertStoredAsync(factory.Services, purchaseOrder, id, updatedValues, createdDate, changedDate);
        using var sentinelAfterResponse = await client.GetAsync($"{route}/{sentinelId}");
        using var sentinelAfter = await JsonAsync(sentinelAfterResponse);
        Assert.Equal(sentinelBefore.RootElement.GetRawText(), sentinelAfter.RootElement.GetRawText());
        await using var final = factory.Services.CreateAsyncScope();
        Assert.Equal(purchaseOrder ? 2 : 0, await final.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().PurchaseOrders.CountAsync());
        Assert.Equal(purchaseOrder ? 0 : 2, await final.ServiceProvider.GetRequiredService<SupplierDbContext>().Suppliers.CountAsync());
        var addresses = await final.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().Addresses.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync();
        Assert.Equal(new[] { "First source address", "Second source address" }, addresses.Select(x => x.AddressLine1));
        Assert.Empty(await final.ServiceProvider.GetRequiredService<SupplierDbContext>().Addresses.ToArrayAsync());
    }

    [Fact]
    public async Task NullableOrderItemCanAttachReparentAndDetachWithoutChangingParentsOrUnrelatedItems()
    {
        await using var factory = fixture.CreateFactory(true);
        using var client = fixture.ClientAs(factory, "service:procurement-parity", ProcurementPermissions.PurchaseOrdersCreate, ProcurementPermissions.PurchaseOrdersRead, ProcurementPermissions.OrderItemsWrite, ProcurementPermissions.OrderItemsRead);
        var first = await ParentAsync(client, "First nullable parent");
        var second = await ParentAsync(client, "Second nullable parent");
        using var firstBeforeResponse = await client.GetAsync($"/purchaseorders/{first}");
        using var secondBeforeResponse = await client.GetAsync($"/purchaseorders/{second}");
        var firstBefore = await firstBeforeResponse.Content.ReadAsStringAsync();
        var secondBefore = await secondBeforeResponse.Content.ReadAsStringAsync();
        using var sentinelCreated = await client.PostAsJsonAsync("/purchaseorders/orderitems", new UpsertOrderItemRequest(second, "Unrelated", "Retained", 2, 3.25m));
        Assert.Equal(HttpStatusCode.Created, sentinelCreated.StatusCode);
        var sentinel = (await sentinelCreated.Content.ReadFromJsonAsync<OrderItemResponse>())!;
        using var created = await client.PostAsJsonAsync("/purchaseorders/orderitems", new UpsertOrderItemRequest(null, "  Orphan  ", "", 3, 12.34m));
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        Assert.NotNull(created.Headers.Location);
        var item = (await created.Content.ReadFromJsonAsync<OrderItemResponse>())!;
        Assert.Null(item.PurchaseOrderId);
        Assert.Equal(37.02m, item.Subtotal);
        using var createdWire = await JsonAsync(created);
        Assert.False(createdWire.RootElement.TryGetProperty("PurchaseOrderId", out _));
        using var located = await client.GetAsync(created.Headers.Location);
        Assert.Equal(item, await located.Content.ReadFromJsonAsync<OrderItemResponse>());
        DateTime? modified = item.ModifiedDate;
        int?[] parents = [first, second, null];
        for (int step = 0; step < parents.Length; step++)
        {
            fixture.Clock.Advance(TimeSpan.FromSeconds(1));
            var request = new UpsertOrderItemRequest(parents[step], $"  Revision{step}  ", step == 2 ? null : "", 7, 0.01m);
            using var updated = await client.PutAsJsonAsync($"/purchaseorders/orderitems/{item.Id}", request);
            Assert.Equal(HttpStatusCode.NoContent, updated.StatusCode);
            using var freshResponse = await client.GetAsync($"/purchaseorders/orderitems/{item.Id}");
            var fresh = (await freshResponse.Content.ReadFromJsonAsync<OrderItemResponse>())!;
            Assert.Equal(item.Id, fresh.Id);
            Assert.Equal(parents[step], fresh.PurchaseOrderId);
            Assert.Equal(request.PartNumber, fresh.PartNumber);
            Assert.Equal(request.Description, fresh.Description);
            Assert.Equal(7, fresh.Quantity);
            Assert.Equal(0.01m, fresh.UnitPrice);
            Assert.Equal(0.07m, fresh.Subtotal);
            Assert.Equal(item.CreatedDate, fresh.CreatedDate);
            Assert.True(fresh.ModifiedDate > modified);
            modified = fresh.ModifiedDate;
            await AssertListAsync(client, first, parents[step] == first ? [item.Id] : []);
            await AssertListAsync(client, second, parents[step] == second ? [sentinel.Id, item.Id] : [sentinel.Id]);
            await using var read = factory.Services.CreateAsyncScope();
            var rows = await read.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().OrderItems.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync();
            Assert.Equal(2, rows.Length);
            var stored = Assert.Single(rows, x => x.Id == item.Id);
            Assert.Equal(fresh.PurchaseOrderId, stored.PurchaseOrderId);
            Assert.Equal(fresh.PartNumber, stored.PartNumber);
            Assert.Equal(fresh.Description, stored.Description);
            Assert.Equal(fresh.Quantity, stored.Quantity);
            Assert.Equal(fresh.UnitPrice, stored.UnitPrice);
            Assert.Equal(fresh.Subtotal, stored.Subtotal);
            Assert.Equal(fresh.CreatedDate, stored.CreatedDate);
            Assert.Equal(fresh.ModifiedDate, stored.ModifiedDate);
            var untouched = Assert.Single(rows, x => x.Id == sentinel.Id);
            Assert.Equal(sentinel, new OrderItemResponse(untouched.Id, untouched.PurchaseOrderId, untouched.PartNumber, untouched.Description, untouched.Quantity, untouched.UnitPrice, untouched.Subtotal, untouched.CreatedDate, untouched.ModifiedDate));
        }
        Assert.Equal(firstBefore, await client.GetStringAsync($"/purchaseorders/{first}"));
        Assert.Equal(secondBefore, await client.GetStringAsync($"/purchaseorders/{second}"));
        await using var final = factory.Services.CreateAsyncScope();
        Assert.Empty(await final.ServiceProvider.GetRequiredService<SupplierDbContext>().Suppliers.ToArrayAsync());
        Assert.Equal(2, await final.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().PurchaseOrders.CountAsync());
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task MissingParentRefusesItemWriteWithoutChangingRowsOrTimestamps(bool update)
    {
        await using var factory = fixture.CreateFactory(true);
        using var client = fixture.ClientAs(factory, "service:procurement-parity", ProcurementPermissions.PurchaseOrdersCreate, ProcurementPermissions.OrderItemsWrite, ProcurementPermissions.OrderItemsRead);
        int parent = await ParentAsync(client, "Missing-parent guard");
        using var created = await client.PostAsJsonAsync("/purchaseorders/orderitems", new UpsertOrderItemRequest(parent, "Retained", "Retained description", 2, 3.25m));
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var item = (await created.Content.ReadFromJsonAsync<OrderItemResponse>())!;
        await using var beforeScope = factory.Services.CreateAsyncScope();
        var before = await beforeScope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().OrderItems.AsNoTracking().OrderBy(x => x.Id).Select(x => new OrderItemResponse(x.Id, x.PurchaseOrderId, x.PartNumber, x.Description, x.Quantity, x.UnitPrice, x.Subtotal, x.CreatedDate, x.ModifiedDate)).ToArrayAsync();
        fixture.Clock.Advance(TimeSpan.FromSeconds(1));
        var request = new UpsertOrderItemRequest(999999, "Refused", "Must not persist", 7, 0.01m);
        using var refused = update
            ? await client.PutAsJsonAsync($"/purchaseorders/orderitems/{item.Id}", request)
            : await client.PostAsJsonAsync("/purchaseorders/orderitems", request);
        Assert.Equal(HttpStatusCode.InternalServerError, refused.StatusCode);
        string error = await refused.Content.ReadAsStringAsync();
        Assert.DoesNotContain("Must not persist", error, StringComparison.Ordinal);
        Assert.DoesNotContain("FK_OrderItem_PurchaseOrder", error, StringComparison.Ordinal);
        await using var afterScope = factory.Services.CreateAsyncScope();
        var after = await afterScope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().OrderItems.AsNoTracking().OrderBy(x => x.Id).Select(x => new OrderItemResponse(x.Id, x.PurchaseOrderId, x.PartNumber, x.Description, x.Quantity, x.UnitPrice, x.Subtotal, x.CreatedDate, x.ModifiedDate)).ToArrayAsync();
        Assert.Equal(before, after);
        using var fresh = await client.GetAsync($"/purchaseorders/orderitems/{item.Id}");
        Assert.Equal(item, await fresh.Content.ReadFromJsonAsync<OrderItemResponse>());
        Assert.Equal(1, await afterScope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().PurchaseOrders.CountAsync());
        Assert.Empty(await afterScope.ServiceProvider.GetRequiredService<SupplierDbContext>().Suppliers.ToArrayAsync());
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task PurchaseOrderDeleteRefusesLiveChildrenThenDeletesOnlyTheReleasedMaster(bool file)
    {
        await using var factory = fixture.CreateFactory(true);
        using var client = fixture.ClientAs(factory, "service:procurement-parity", ProcurementPermissions.PurchaseOrdersCreate, ProcurementPermissions.PurchaseOrdersRead, ProcurementPermissions.PurchaseOrdersDelete,
            ProcurementPermissions.OrderItemsWrite, ProcurementPermissions.OrderItemsRead, ProcurementPermissions.OrderItemsDelete,
            ProcurementPermissions.FilesWrite, ProcurementPermissions.FilesRead, ProcurementPermissions.FilesDelete);
        await using (var seed = factory.Services.CreateAsyncScope())
        {
            var orders = seed.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
            orders.Addresses.AddRange(new PurchaseOrderAddress { Id = 101, AddressLine1 = "Retained shipping" }, new PurchaseOrderAddress { Id = 102, AddressLine1 = "Retained billing" });
            var suppliers = seed.ServiceProvider.GetRequiredService<SupplierDbContext>();
            suppliers.Suppliers.Add(new Supplier { Name = "Unrelated supplier" });
            await orders.SaveChangesAsync();
            await suppliers.SaveChangesAsync();
        }
        using var created = await client.PostAsJsonAsync("/purchaseorders", new { ShippingAddressId = 101, BillingAddressId = 102, Notes = "Owned delete candidate" });
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var master = (await created.Content.ReadFromJsonAsync<PurchaseOrderResponse>())!;
        int sentinel = await ParentAsync(client, "Unrelated purchase order");
        var sentinelBefore = await client.GetStringAsync($"/purchaseorders/{sentinel}");
        using var attached = file
            ? await client.PostAsync($"/purchaseorders/{master.Id}/files?bucket=source-delete&objectName=retained-object", null)
            : await client.PostAsJsonAsync("/purchaseorders/orderitems", new UpsertOrderItemRequest(master.Id, "Retained item", "Retained description", 3, 12.34m));
        Assert.Equal(HttpStatusCode.Created, attached.StatusCode);
        using var child = await JsonAsync(attached);
        int childId = child.RootElement.GetProperty("Id").GetInt32();
        string before = await GraphSnapshotAsync(factory.Services);
        using var refused = await client.DeleteAsync($"/purchaseorders/{master.Id}");
        Assert.Equal(HttpStatusCode.InternalServerError, refused.StatusCode);
        Assert.Equal(before, await GraphSnapshotAsync(factory.Services));
        using var freshMaster = await client.GetAsync($"/purchaseorders/{master.Id}");
        Assert.Equal(master, await freshMaster.Content.ReadFromJsonAsync<PurchaseOrderResponse>());
        using var detached = await client.DeleteAsync(file ? $"/purchaseorders/files/{childId}" : $"/purchaseorders/orderitems/{childId}");
        Assert.Equal(HttpStatusCode.NoContent, detached.StatusCode);
        using var deleted = await client.DeleteAsync($"/purchaseorders/{master.Id}");
        Assert.Equal(HttpStatusCode.NoContent, deleted.StatusCode);
        using var missing = await client.GetAsync($"/purchaseorders/{master.Id}");
        using var replay = await client.DeleteAsync($"/purchaseorders/{master.Id}");
        Assert.Equal(HttpStatusCode.NotFound, missing.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, replay.StatusCode);
        Assert.Equal(sentinelBefore, await client.GetStringAsync($"/purchaseorders/{sentinel}"));
        await using var final = factory.Services.CreateAsyncScope();
        var database = final.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
        Assert.Equal(sentinel, (await database.PurchaseOrders.AsNoTracking().SingleAsync()).Id);
        Assert.Empty(await database.OrderItems.ToArrayAsync());
        Assert.Empty(await database.Files.ToArrayAsync());
        Assert.Equal(new[] { "Retained shipping", "Retained billing" }, (await database.Addresses.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync()).Select(x => x.AddressLine1));
        Assert.Equal("Unrelated supplier", (await final.ServiceProvider.GetRequiredService<SupplierDbContext>().Suppliers.AsNoTracking().SingleAsync()).Name);
    }

    private static async Task<string> GraphSnapshotAsync(IServiceProvider services)
    {
        await using var scope = services.CreateAsyncScope();
        var orders = scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
        var suppliers = scope.ServiceProvider.GetRequiredService<SupplierDbContext>();
        return JsonSerializer.Serialize(new
        {
            Suppliers = await suppliers.Suppliers.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync(),
            SupplierAddresses = await suppliers.Addresses.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync(),
            Orders = await orders.PurchaseOrders.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync(),
            OrderAddresses = await orders.Addresses.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync(),
            Items = await orders.OrderItems.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync(),
            Files = await orders.Files.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync(),
        });
    }

    private static Dictionary<string, object?> Values(bool order, int mode, string phase)
    {
        var result = (order ? OrderStrings : SupplierStrings).ToDictionary(x => x, x => mode switch
        {
            1 => x == "Name" ? (object?)"" : null,
            2 => "",
            3 => $"  {phase} {x}  ",
            _ => $"{phase}-{x}"
        }, StringComparer.Ordinal);
        if (order)
        {
            result["SupplierId"] = mode == 1 ? null : phase == "updated" ? 902 : 901;
            result["EmployeeId"] = mode == 1 ? null : phase == "updated" ? 802 : 801;
            result["ShippingAddressId"] = mode == 1 ? null : phase == "updated" ? 102 : 101;
            result["BillingAddressId"] = mode == 1 ? null : phase == "updated" ? 101 : 102;
        }
        return result;
    }

    private static void AssertFields(JsonElement actual, Dictionary<string, object?> expected)
    {
        foreach (var (key, value) in expected)
        {
            Assert.False(actual.TryGetProperty(char.ToLowerInvariant(key[0]) + key[1..], out _));
            if (value is null) Assert.False(actual.TryGetProperty(key, out _));
            else if (value is int number) Assert.Equal(number, actual.GetProperty(key).GetInt32());
            else Assert.Equal((string)value, actual.GetProperty(key).GetString());
        }
    }

    private static async Task AssertStoredAsync(IServiceProvider services, bool order, int id, Dictionary<string, object?> expected, DateTime created, DateTime modified)
    {
        await using var scope = services.CreateAsyncScope();
        DbContext context;
        object row;
        if (order)
        {
            var db = scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
            context = db;
            row = await db.PurchaseOrders.AsNoTracking().SingleAsync(x => x.Id == id);
        }
        else
        {
            var db = scope.ServiceProvider.GetRequiredService<SupplierDbContext>();
            context = db;
            row = await db.Suppliers.AsNoTracking().SingleAsync(x => x.Id == id);
            Assert.Null(((Supplier)row).AddressId);
        }
        var entry = context.Entry(row);
        foreach (var (key, value) in expected) Assert.Equal(value, entry.Property(key).CurrentValue);
        Assert.Equal(created, entry.Property("CreatedDate").CurrentValue);
        Assert.Equal(modified, entry.Property("ModifiedDate").CurrentValue);
    }

    private static async Task<JsonDocument> JsonAsync(HttpResponseMessage response) => JsonDocument.Parse(await response.Content.ReadAsStringAsync());

    private static async Task<int> ParentAsync(HttpClient client, string notes)
    {
        using var response = await client.PostAsJsonAsync("/purchaseorders", new UpsertPurchaseOrderRequest(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, notes));
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        using var json = await JsonAsync(response);
        return json.RootElement.GetProperty("Id").GetInt32();
    }

    private static async Task AssertListAsync(HttpClient client, int parent, int[] expected)
    {
        using var response = await client.GetAsync($"/purchaseorders/{parent}/orderitems");
        if (expected.Length == 0) Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        else
        {
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var rows = (await response.Content.ReadFromJsonAsync<OrderItemResponse[]>())!;
            Assert.Equal(expected.Order(), rows.Select(x => x.Id));
            Assert.All(rows, x => Assert.Equal(parent, x.PurchaseOrderId));
        }
    }
}
