using System.Net;
using System.Net.Http.Json;
using Legacy.Maliev.ProcurementService.Api.Authorization;
using Legacy.Maliev.ProcurementService.Application.Interfaces;
using Legacy.Maliev.ProcurementService.Application.Models;
using Legacy.Maliev.ProcurementService.Data;
using Legacy.Maliev.ProcurementService.Domain;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Legacy.Maliev.ProcurementService.Tests.Integration;

public sealed class OrderItemPartNumberWriteGuardTests(ProcurementRuntimeFixture fixture)
    : IClassFixture<ProcurementRuntimeFixture>, IAsyncLifetime
{
    public Task InitializeAsync() => fixture.ResetAsync();
    public Task DisposeAsync() => Task.CompletedTask;

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Exact100Utf16_RoundTripsAndPreservesUnboundedDescription(bool supplementary)
    {
        var literal = supplementary ? string.Concat(Enumerable.Repeat("😀", 49)) + "  " : new string('ก', 98) + "  ";
        Assert.Equal(100, literal.Length);
        await RoundTripAsync(literal);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("  ")]
    [InlineData(" ก padded ")]
    public Task NullableEmptyAndPaddingRemainLiteral(string? literal) => RoundTripAsync(literal);

    private async Task RoundTripAsync(string? literal)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        using var client = fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.OrderItemsWrite, ProcurementPermissions.OrderItemsRead);
        var request = Request(literal);
        using var created = await client.PostAsJsonAsync("/purchaseorders/orderitems", request);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var item = (await created.Content.ReadFromJsonAsync<OrderItemResponse>())!;
        Assert.Equal(literal, item.PartNumber);
        Assert.Equal(request.Description, item.Description);
        Assert.Equal(3.75m, item.Subtotal);
        using var updated = await client.PutAsJsonAsync($"/purchaseorders/orderitems/{item.Id}", request with { Description = request.Description + " revision ", Quantity = 4 });
        Assert.Equal(HttpStatusCode.NoContent, updated.StatusCode);
        var fresh = (await client.GetFromJsonAsync<OrderItemResponse>($"/purchaseorders/orderitems/{item.Id}"))!;
        Assert.Equal(literal, fresh.PartNumber);
        Assert.Equal(request.Description + " revision ", fresh.Description);
        Assert.Equal(5m, fresh.Subtotal);
        await using var scope = app.Services.CreateAsyncScope();
        var repository = scope.ServiceProvider.GetRequiredService<IPurchaseOrderRepository>();
        var direct = await repository.CreateOrderItemAsync(request with { PurchaseOrderId = null }, default);
        Assert.Null(direct.PurchaseOrderId);
        Assert.Equal(literal, direct.PartNumber);
        Assert.Equal(UpdateResult.Updated, await repository.UpdateOrderItemAsync(direct.Id, request with { PurchaseOrderId = null }, null, default));
        var rows = await scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().OrderItems.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync();
        Assert.Equal(2, rows.Length);
        Assert.All(rows, row => Assert.Equal(literal, row.PartNumber));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ApiOverflowAt101_ReturnsBadRequestBeforeChangingEitherDatabase(bool supplementary)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        using var client = fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.OrderItemsWrite, ProcurementPermissions.OrderItemsRead);
        using var created = await client.PostAsJsonAsync("/purchaseorders/orderitems", Request("original"));
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var item = (await created.Content.ReadFromJsonAsync<OrderItemResponse>())!;
        var before = await GraphAsync(app);
        var invalid = supplementary ? string.Concat(Enumerable.Repeat("😀", 50)) + "ก" : new string('ก', 101);
        Assert.Equal(101, invalid.Length);
        using var create = await client.PostAsJsonAsync("/purchaseorders/orderitems", Request(invalid));
        using var update = await client.PutAsJsonAsync($"/purchaseorders/orderitems/{item.Id}", Request(invalid) with { Quantity = 9 });
        Assert.Equal(HttpStatusCode.BadRequest, create.StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, update.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Fact]
    public async Task MissingItem_PrecedesOverflowValidation()
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        using var client = fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.OrderItemsWrite);
        var before = await GraphAsync(app);
        using var update = await client.PutAsJsonAsync("/purchaseorders/orderitems/999999", Request(new string('ก', 101)));
        Assert.Equal(HttpStatusCode.NotFound, update.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task DirectOverflow_PreservesTrackedFieldsAndConcurrencyOriginalValue(bool supplementary)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        await using var scope = app.Services.CreateAsyncScope();
        var repository = scope.ServiceProvider.GetRequiredService<IPurchaseOrderRepository>();
        var item = await repository.CreateOrderItemAsync(Request("original"), default);
        var database = scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
        var row = await database.OrderItems.FindAsync(item.Id) ?? throw new InvalidOperationException("Synthetic item missing.");
        var entry = database.Entry(row);
        var originalModified = entry.Property(x => x.ModifiedDate).OriginalValue;
        var before = await GraphAsync(app);
        var invalid = supplementary ? string.Concat(Enumerable.Repeat("😀", 51)) : new string('ก', 101);
        var request = Request(invalid) with { Quantity = 99, PurchaseOrderId = null };
        await Assert.ThrowsAsync<ArgumentException>(() => repository.CreateOrderItemAsync(request, default));
        await Assert.ThrowsAsync<ArgumentException>(() => repository.UpdateOrderItemAsync(item.Id, request, new DateTimeOffset(2025, 1, 1, 0, 0, 0, TimeSpan.Zero), default));
        Assert.Equal(UpdateResult.NotFound, await repository.UpdateOrderItemAsync(999999, request, null, default));
        Assert.Equal(originalModified, entry.Property(x => x.ModifiedDate).OriginalValue);
        Assert.Equal(item.PartNumber, row.PartNumber);
        Assert.Equal(item.Quantity, row.Quantity);
        Assert.Equal(item.PurchaseOrderId, row.PurchaseOrderId);
        Assert.DoesNotContain(database.ChangeTracker.Entries(), value => value.State is EntityState.Modified or EntityState.Added or EntityState.Deleted);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task AuthorizationRefusesBeforeMutation(bool authenticated)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        using var client = authenticated ? fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.PurchaseOrdersRead) : app.CreateClient();
        var before = await GraphAsync(app);
        using var create = await client.PostAsJsonAsync("/purchaseorders/orderitems", Request(new string('ก', 101)));
        Assert.Equal(authenticated ? HttpStatusCode.Forbidden : HttpStatusCode.Unauthorized, create.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    private static UpsertOrderItemRequest Request(string? partNumber) => new(93, partNumber, " " + new string('ก', 300) + " ", 3, 1.25m);
    private static async Task SeedAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var orders = scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
        orders.PurchaseOrders.Add(new PurchaseOrder { Id = 93 });
        await orders.SaveChangesAsync();
        var suppliers = scope.ServiceProvider.GetRequiredService<SupplierDbContext>();
        suppliers.Suppliers.Add(new Supplier { Id = 91, Name = "Synthetic retained supplier" });
        await suppliers.SaveChangesAsync();
    }
    private static async Task<string> GraphAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        var snapshots = new List<string>();
        foreach (var boundary in new[]
        {
            (Context: (DbContext)scope.ServiceProvider.GetRequiredService<SupplierDbContext>(), Tables: new[] { "Address", "Supplier", "SupplierCreateReceipt" }),
            (Context: (DbContext)scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>(), Tables: new[] { "Address", "PurchaseOrder", "OrderItem", "PurchaseOrderFile", "PurchaseOrderCreateReceipt" }),
        })
            foreach (var table in boundary.Tables)
            {
                var sql = $"SELECT COALESCE(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]') AS \"Value\" FROM public.\"{table}\" r";
                snapshots.Add(boundary.Context.GetType().Name + ":" + table + ":" + await boundary.Context.Database.SqlQueryRaw<string>(sql).SingleAsync(lifetime.Token));
            }
        return string.Join("\n", snapshots);
    }
}
