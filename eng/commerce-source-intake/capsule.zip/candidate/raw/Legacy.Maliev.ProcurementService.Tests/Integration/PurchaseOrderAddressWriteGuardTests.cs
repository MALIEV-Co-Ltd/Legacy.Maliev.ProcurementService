using System.Net;
using System.Net.Http.Json;
using Legacy.Maliev.ProcurementService.Api.Authorization;
using Legacy.Maliev.ProcurementService.Application.Interfaces;
using Legacy.Maliev.ProcurementService.Application.Models;
using Legacy.Maliev.ProcurementService.Data;
using Legacy.Maliev.ProcurementService.Domain;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Legacy.Maliev.ProcurementService.Tests.Integration;

public sealed class PurchaseOrderAddressWriteGuardTests(ProcurementRuntimeFixture fixture)
    : IClassFixture<ProcurementRuntimeFixture>, IAsyncLifetime
{
    public Task InitializeAsync() => fixture.ResetAsync();
    public Task DisposeAsync() => Task.CompletedTask;

    [Theory]
    [InlineData("Building")]
    [InlineData("AddressLine1")]
    [InlineData("AddressLine2")]
    [InlineData("City")]
    [InlineData("State")]
    [InlineData("PostalCode")]
    public async Task EachFieldPreserves256BmpAndSupplementaryUnitsAndRefuses257BeforeMutation(string field)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        using var client = fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.PurchaseOrderAddressesWrite, ProcurementPermissions.PurchaseOrderAddressesRead);
        var exact = new string('ก', 254) + "  ";
        using var created = await client.PostAsJsonAsync("/purchaseorders/addresses", Field(field, exact));
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var address = (await created.Content.ReadFromJsonAsync<PurchaseOrderAddressResponse>())!;
        Assert.Equal(exact, Value(address, field));
        var supplementary = string.Concat(Enumerable.Repeat("😀", 127)) + "  ";
        Assert.Equal(256, supplementary.Length);
        using var updated = await client.PutAsJsonAsync($"/purchaseorders/addresses/{address.Id}", Field(field, supplementary));
        Assert.Equal(HttpStatusCode.NoContent, updated.StatusCode);
        var fresh = (await client.GetFromJsonAsync<PurchaseOrderAddressResponse>($"/purchaseorders/addresses/{address.Id}"))!;
        Assert.Equal(supplementary, Value(fresh, field));
        await using (var read = app.Services.CreateAsyncScope())
        {
            var row = await read.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().Addresses.AsNoTracking().SingleAsync();
            Assert.Equal(fresh, Response(row));
        }
        var before = await GraphAsync(app);
        foreach (var invalid in new[] { exact + "ก", supplementary + "ก" })
        {
            Assert.Equal(257, invalid.Length);
            using var create = await client.PostAsJsonAsync("/purchaseorders/addresses", Field(field, invalid));
            using var update = await client.PutAsJsonAsync($"/purchaseorders/addresses/{address.Id}", Field(field, invalid) with { CountryId = 999 });
            Assert.Equal(HttpStatusCode.BadRequest, create.StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, update.StatusCode);
            Assert.Equal(before, await GraphAsync(app));
        }
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("  ")]
    [InlineData(" ก padded ")]
    public async Task OptionalNullAndRequiredEmptyPaddingPreserveLiteralCountryZero(string? literal)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        var request = new UpsertPurchaseOrderAddressRequest(literal, literal ?? "required", literal, literal, literal, literal, 0);
        using var client = fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.PurchaseOrderAddressesWrite, ProcurementPermissions.PurchaseOrderAddressesRead);
        using var create = await client.PostAsJsonAsync("/purchaseorders/addresses", request);
        Assert.Equal(HttpStatusCode.Created, create.StatusCode);
        var original = (await create.Content.ReadFromJsonAsync<PurchaseOrderAddressResponse>())!;
        using var update = await client.PutAsJsonAsync($"/purchaseorders/addresses/{original.Id}", request);
        Assert.Equal(HttpStatusCode.NoContent, update.StatusCode);
        var fresh = (await client.GetFromJsonAsync<PurchaseOrderAddressResponse>($"/purchaseorders/addresses/{original.Id}"))!;
        Assert.Equal(literal, fresh.Building);
        Assert.Equal(request.AddressLine1, fresh.AddressLine1);
        Assert.Equal(literal, fresh.AddressLine2);
        Assert.Equal(literal, fresh.City);
        Assert.Equal(literal, fresh.State);
        Assert.Equal(literal, fresh.PostalCode);
        Assert.Equal(0, fresh.CountryId);
        await using var scope = app.Services.CreateAsyncScope();
        var repository = scope.ServiceProvider.GetRequiredService<IPurchaseOrderRepository>();
        var direct = await repository.CreateAddressAsync(request, default);
        Assert.True(await repository.UpdateAddressAsync(direct.Id, request, default));
        var rows = await scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>().Addresses.AsNoTracking().ToArrayAsync();
        Assert.Equal(2, rows.Length);
        Assert.All(rows, row => Assert.Equal(request.AddressLine1, row.AddressLine1));
    }

    [Theory]
    [InlineData("Building")]
    [InlineData("AddressLine1")]
    [InlineData("AddressLine2")]
    [InlineData("City")]
    [InlineData("State")]
    [InlineData("PostalCode")]
    public async Task DirectFieldOverflowRefusesBeforeChangingTrackedFieldsOrSupplierDatabase(string field)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        await using var scope = app.Services.CreateAsyncScope();
        var repository = scope.ServiceProvider.GetRequiredService<IPurchaseOrderRepository>();
        var address = await repository.CreateAddressAsync(Field("City", "original"), default);
        var database = scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>();
        var row = await database.Addresses.FindAsync(address.Id) ?? throw new InvalidOperationException("Synthetic address missing.");
        var before = await GraphAsync(app);
        var invalid = Field(field, string.Concat(Enumerable.Repeat("😀", 129))) with { CountryId = 999 };
        await Assert.ThrowsAsync<ArgumentException>(() => repository.CreateAddressAsync(invalid, default));
        await Assert.ThrowsAsync<ArgumentException>(() => repository.UpdateAddressAsync(address.Id, invalid, default));
        Assert.False(await repository.UpdateAddressAsync(999999, invalid, default));
        Assert.Equal(address, Response(row));
        Assert.DoesNotContain(database.ChangeTracker.Entries(), value => value.State is EntityState.Modified or EntityState.Added or EntityState.Deleted);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Fact]
    public async Task RequiredLineNullRefusesDirectWritesAndExistingControllerPolicyRemainsBadRequest()
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        await using var scope = app.Services.CreateAsyncScope();
        var repository = scope.ServiceProvider.GetRequiredService<IPurchaseOrderRepository>();
        var address = await repository.CreateAddressAsync(Field("City", "original"), default);
        var before = await GraphAsync(app);
        var invalid = Field("AddressLine1", null);
        await Assert.ThrowsAsync<ArgumentException>(() => repository.CreateAddressAsync(invalid, default));
        await Assert.ThrowsAsync<ArgumentException>(() => repository.UpdateAddressAsync(address.Id, invalid, default));
        Assert.False(await repository.UpdateAddressAsync(999999, invalid, default));
        using var client = fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.PurchaseOrderAddressesWrite);
        using var create = await client.PostAsJsonAsync("/purchaseorders/addresses", invalid);
        using var update = await client.PutAsJsonAsync($"/purchaseorders/addresses/{address.Id}", invalid);
        Assert.Equal(HttpStatusCode.BadRequest, create.StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, update.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Fact]
    public async Task MissingAddressPrecedesOverflowValidation()
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        using var client = fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.PurchaseOrderAddressesWrite);
        var before = await GraphAsync(app);
        using var update = await client.PutAsJsonAsync("/purchaseorders/addresses/999999", Field("City", new string('ก', 257)));
        Assert.Equal(HttpStatusCode.NotFound, update.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task MissingAuthorizationCannotMutateEitherAddressSchema(bool authenticated)
    {
        await using var app = fixture.CreateFactory(true);
        await SeedAsync(app);
        using var client = authenticated ? fixture.ClientAs(app, "service:procurement-parity", ProcurementPermissions.PurchaseOrdersRead) : app.CreateClient();
        var before = await GraphAsync(app);
        using var create = await client.PostAsJsonAsync("/purchaseorders/addresses", Field("City", new string('ก', 257)));
        Assert.Equal(authenticated ? HttpStatusCode.Forbidden : HttpStatusCode.Unauthorized, create.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    private static UpsertPurchaseOrderAddressRequest Field(string field, string? literal)
    {
        var request = new UpsertPurchaseOrderAddressRequest(null, "required", null, null, null, null, 0);
        return field switch
        {
            "Building" => request with { Building = literal },
            "AddressLine1" => request with { AddressLine1 = literal! },
            "AddressLine2" => request with { AddressLine2 = literal },
            "City" => request with { City = literal },
            "State" => request with { State = literal },
            "PostalCode" => request with { PostalCode = literal },
            _ => throw new ArgumentException("Unknown synthetic field.", nameof(field)),
        };
    }
    private static string? Value(PurchaseOrderAddressResponse row, string field) => field switch
    {
        "Building" => row.Building, "AddressLine1" => row.AddressLine1, "AddressLine2" => row.AddressLine2,
        "City" => row.City, "State" => row.State, "PostalCode" => row.PostalCode,
        _ => throw new ArgumentException("Unknown synthetic field.", nameof(field)),
    };
    private static PurchaseOrderAddressResponse Response(PurchaseOrderAddress row) => new(row.Id, row.Building, row.AddressLine1, row.AddressLine2, row.City, row.State, row.PostalCode, row.CountryId, row.CreatedDate, row.ModifiedDate);
    private static async Task SeedAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var database = scope.ServiceProvider.GetRequiredService<SupplierDbContext>();
        database.Addresses.Add(new SupplierAddress { Id = 91, Address1 = "Supplier schema retained", CountryId = 0 });
        database.Suppliers.Add(new Supplier { Id = 92, AddressId = 91, Name = "Synthetic supplier" });
        await database.SaveChangesAsync();
    }
    private static async Task<string> GraphAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        var snapshots = new List<string>();
        foreach (var boundary in new[]
        {
            (Context: (DbContext)scope.ServiceProvider.GetRequiredService<SupplierDbContext>(), Tables: new[] { "Address", "Supplier", "SupplierCreateReceipt" }),
            (Context: (DbContext)scope.ServiceProvider.GetRequiredService<PurchaseOrderDbContext>(), Tables: new[] { "Address", "PurchaseOrder", "OrderItem", "PurchaseOrderFile", "PurchaseOrderCreateReceipt" }),
        })
            foreach (var table in boundary.Tables)
            {
                var sql = $"SELECT COALESCE(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]') AS \"Value\" FROM public.\"{table}\" r";
                snapshots.Add(boundary.Context.GetType().Name + ":" + table + ":" + await boundary.Context.Database.SqlQueryRaw<string>(sql).SingleAsync(lifetime.Token));
            }
        return string.Join("\n", snapshots);
    }
}
