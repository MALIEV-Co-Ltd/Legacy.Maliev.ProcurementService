using Legacy.Maliev.ProcurementService.Application.Models;

namespace Legacy.Maliev.ProcurementService.Data;

/// <summary>Checks the isolated PurchaseOrder address source contract without altering literals.</summary>
internal static class PurchaseOrderAddressSourceConstraints
{
    internal static void Validate(UpsertPurchaseOrderAddressRequest request)
    {
        if (request.AddressLine1 is null || request.AddressLine1.Length > 256
            || request.Building?.Length > 256 || request.AddressLine2?.Length > 256
            || request.City?.Length > 256 || request.State?.Length > 256 || request.PostalCode?.Length > 256)
            throw new ArgumentException("The request is invalid.", nameof(request));
    }
}
