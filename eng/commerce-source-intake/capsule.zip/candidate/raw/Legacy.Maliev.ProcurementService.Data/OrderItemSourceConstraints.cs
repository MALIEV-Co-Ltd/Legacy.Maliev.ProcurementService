namespace Legacy.Maliev.ProcurementService.Data;

/// <summary>Checks nullable source part numbers before tracked writes without altering literals.</summary>
internal static class OrderItemSourceConstraints
{
    internal static void ValidatePartNumber(string? partNumber)
    {
        if (partNumber?.Length > 100)
            throw new ArgumentException("The request is invalid.", nameof(partNumber));
    }
}
