"""Verify original native executions for the three source write-guard cohorts."""
import collections
import hashlib
import json
import os
import re
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

EXPECTED = {'PurchaseOrderFileBucketWriteGuardTests': {'LiteralUtf16Boundary_RoundTripsCreateAndUpdateWithUnboundedObjectName': {'parameter': 'supplementary', 'values': [False, True]}, 'JsonUpdateAndDirectWrites_PreserveAcceptedEmptyAndPadding': {'parameter': 'literal', 'values': ['', '  ', ' ก padded ']}, 'ApiOverflowAt51_IsBadRequestAndLeavesBothDatabaseGraphsUnchanged': {'parameter': 'supplementary', 'values': [False, True]}, 'MissingParentOrFile_PrecedesBucketOverflow': {'parameter': 'update', 'values': [False, True]}, 'DirectRepositoryInvalidBucket_FailsBeforeTrackedMutationAndRetainsMissingPrecedence': {'parameter': 'mode', 'values': [None, 'bmp', 'supplementary']}, 'MissingAuthorization_RefusesBeforeFileMutation': {'parameter': 'authenticated', 'values': [False, True]}}, 'OrderItemPartNumberWriteGuardTests': {'Exact100Utf16_RoundTripsAndPreservesUnboundedDescription': {'parameter': 'supplementary', 'values': [False, True]}, 'NullableEmptyAndPaddingRemainLiteral': {'parameter': 'literal', 'values': [None, '', '  ', ' ก padded ']}, 'ApiOverflowAt101_ReturnsBadRequestBeforeChangingEitherDatabase': {'parameter': 'supplementary', 'values': [False, True]}, 'MissingItem_PrecedesOverflowValidation': {'parameter': None, 'values': []}, 'DirectOverflow_PreservesTrackedFieldsAndConcurrencyOriginalValue': {'parameter': 'supplementary', 'values': [False, True]}, 'AuthorizationRefusesBeforeMutation': {'parameter': 'authenticated', 'values': [False, True]}}, 'PurchaseOrderAddressWriteGuardTests': {'EachFieldPreserves256BmpAndSupplementaryUnitsAndRefuses257BeforeMutation': {'parameter': 'field', 'values': ['Building', 'AddressLine1', 'AddressLine2', 'City', 'State', 'PostalCode']}, 'OptionalNullAndRequiredEmptyPaddingPreserveLiteralCountryZero': {'parameter': 'literal', 'values': [None, '', '  ', ' ก padded ']}, 'DirectFieldOverflowRefusesBeforeChangingTrackedFieldsOrSupplierDatabase': {'parameter': 'field', 'values': ['Building', 'AddressLine1', 'AddressLine2', 'City', 'State', 'PostalCode']}, 'RequiredLineNullRefusesDirectWritesAndExistingControllerPolicyRemainsBadRequest': {'parameter': None, 'values': []}, 'MissingAddressPrecedesOverflowValidation': {'parameter': None, 'values': []}, 'MissingAuthorizationCannotMutateEitherAddressSchema': {'parameter': 'authenticated', 'values': [False, True]}}}
MAX_BYTES = 64 * 1024 * 1024
NS = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}

def read(path):
    for part in (path, *path.parents):
        assert not part.is_symlink() and not part.is_junction(), "Linked evidence refused"
    assert path.stat().st_size <= MAX_BYTES, "Evidence size exceeds limit"
    with path.open("rb") as stream:
        value = stream.read(MAX_BYTES + 1)
    assert len(value) <= MAX_BYTES and b"<!DOCTYPE" not in value, "Unsafe evidence refused"
    return value

def verify(root):
    files = []
    entries = 0
    for folder, directories, names in os.walk(root, followlinks=False):
        entries += len(directories) + len(names)
        assert entries <= 256, "Evidence inventory exceeds limit"
        for name in directories:
            path = Path(folder) / name
            assert not path.is_symlink() and not path.is_junction(), "Linked inventory refused"
        files.extend(Path(folder) / name for name in names)
    assert sum(path.stat().st_size for path in files) <= 256 * 1024 * 1024, "Evidence aggregate exceeds limit"
    reports = [path for path in files if path.suffix == ".trx"]
    assert len(reports) == 1, "Expected exactly one TRX"
    content = read(reports[0])
    document = ET.fromstring(content)
    assert document.tag == "{" + NS["t"] + "}TestRun", "Wrong native TRX root"
    def nodes(local):
        matches = [node for node in document.iter() if node.tag.rsplit("}", 1)[-1] == local]
        assert all(node.tag == "{" + NS["t"] + "}" + local for node in matches), "Wrong native namespace"
        return matches
    for local in ("TestRun", "Results", "TestDefinitions", "ResultSummary", "Counters"):
        assert len(nodes(local)) == 1, "Duplicate or missing native section"
    for local in ("Results", "TestDefinitions", "ResultSummary"):
        assert len(document.findall("./t:" + local, NS)) == 1, "Hidden native section"
    assert len(document.findall("./t:ResultSummary/t:Counters", NS)) == 1, "Hidden native counters"
    definitions = document.findall("./t:TestDefinitions/t:UnitTest", NS)
    assert len(nodes("UnitTest")) == len(definitions), "Hidden test definition"
    assert len(nodes("TestMethod")) == len(definitions), "Duplicate or hidden test method"
    assert all(len(node.findall("./t:TestMethod", NS)) == 1 for node in definitions)
    ids = [node.get("id") for node in definitions]
    assert all(ids) and len(set(ids)) == len(ids), "Invalid test definition identities"
    methods = {node.get("id"): node.find("t:TestMethod", NS) for node in definitions}
    results = document.findall("./t:Results/t:UnitTestResult", NS)
    assert len(nodes("UnitTestResult")) == len(results), "Hidden or nested native result"
    execution_ids = [node.get("executionId") for node in results]
    assert all(execution_ids) and len(set(execution_ids)) == len(execution_ids), "Duplicate execution identity"
    expected_cases = set()
    for entity, methods_expected in EXPECTED.items():
        for name, spec in methods_expected.items():
            for value in spec["values"] if spec["parameter"] else [None]:
                expected_cases.add((entity, name, type(value).__name__, json.dumps(value, ensure_ascii=False)))
    assert len(definitions) == len(results) == 47, "Focused definition/result cardinality drift"
    actual_cases = set()
    used_ids = set()
    for node in results:
        assert node.get("outcome") == "Passed" and node.get("testId") in methods, "Nonpassing or unknown execution"
        used_ids.add(node.get("testId"))
        method = methods[node.get("testId")]
        qualified = method.get("className", "").split(",")[0]
        entity = qualified.rsplit(".", 1)[-1]
        assert qualified == "Legacy.Maliev.ProcurementService.Tests.Integration." + entity and entity in EXPECTED, "Wrong focused class"
        name = method.get("name")
        assert name in EXPECTED[entity], "Unknown focused method"
        spec = EXPECTED[entity][name]
        prefix = qualified + "." + name
        display = node.get("testName", "")
        if spec["parameter"]:
            beginning = prefix + "(" + spec["parameter"] + ": "
            assert display.startswith(beginning) and display.endswith(")"), "Wrong theory argument identity"
            raw = display[len(beginning):-1]
            if raw.lower() in {"true", "false", "null"}:
                value = json.loads(raw.lower())
            else:
                value = json.loads(raw)
                assert isinstance(value, str), "Unexpected theory argument type"
        else:
            assert display == prefix, "Wrong fact identity"
            value = None
        case = (entity, name, type(value).__name__, json.dumps(value, ensure_ascii=False))
        assert case in expected_cases and case not in actual_cases, "Unknown or duplicate theory tuple"
        actual_cases.add(case)
    assert actual_cases == expected_cases and used_ids == set(methods), "Missing focused case or orphan definition"
    counters = document.find("./t:ResultSummary/t:Counters", NS)
    assert counters is not None
    assert all(int(counters.get(key, "-1")) == 47 for key in ("total", "executed", "passed"))
    failures = ("failed", "error", "timeout", "aborted", "inconclusive", "notExecuted", "disconnected", "warning", "passedButRunAborted")
    assert all(key in counters.attrib for key in failures), "Missing native failure counters"
    assert all(int(counters.get(key)) == 0 for key in failures)
    raw = [read(path) for path in files if path.name == "coverage.cobertura.xml"]
    assert raw and len({hashlib.sha256(value).hexdigest() for value in raw}) == 1, "Raw coverage absent or mismatched"
    packages = ET.fromstring(raw[0]).findall("./packages/package")
    for assembly in ("Api", "Application", "Data", "Domain"):
        matches = [node for node in packages if node.get("name") == "Legacy.Maliev.ProcurementService." + assembly]
        assert matches and any(node.findall(".//line") for node in matches), "Missing owned coverage inventory"
    return {"passed": 47, "failed": 0, "skipped": 0, "cases": EXPECTED,
            "trxSha256": hashlib.sha256(content).hexdigest(), "rawSha256": hashlib.sha256(raw[0]).hexdigest(),
            "rawCopies": len(raw), "head": os.environ.get("GITHUB_SHA"),
            "note": "47 guard cases only. Full377 suite must retain all prior accepted cases and gate all four assemblies at80 without exclusions; persistentDDL is not accepted."}

if __name__ == "__main__":
    root = Path(sys.argv[1]).absolute()
    receipt = verify(root)
    (root / "procurement-write-guards-proof.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt))
