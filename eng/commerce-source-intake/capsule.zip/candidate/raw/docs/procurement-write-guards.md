This hosted qualification profile targets the reviewed Procurement20 producer and its exact three guard-test source files. Its workflow, native TRX verifier and documentation are integrated into the Procurement23 source candidate; they have not been committed, pushed or dispatched.

The focused forecast is47 executions:14 bucket,13 part-number and20 PurchaseOrder address cases. The verifier checks original class/method identities, each expected boolean/null/string argument tuple, complete native definitions/results/counters, no duplicate/failed/skipped cases, and matching raw coverage copies with all four owned assemblies present. Its28 synthetic parser controls are not C# or database acceptance.

The existing full-write workflow retains its13 dedicated cases. Full377 qualification, zero-warning build, formatter, vulnerability audit and secret scan remain separate required gates. Focused guard coverage does not establish the full-suite80-percent coverage threshold.

The YAML retains the reviewed checkout/dependency/shared-action pins, read-only permissions,30-minute job timeout and always-preserved archived evidence. Candidate publication must follow the owner's build/test/commit gates; no clean producer pin or Financial eight-service acceptance is inferred from this draft.
